const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-J4Z94I1R.js","assets/index-DNzFMgCo.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./index-C8bepJEK.js";import{registerPlugin as p}from"./index-DNzFMgCo.js";const _=p("AppLauncher",{web:()=>r(()=>import("./web-J4Z94I1R.js"),__vite__mapDeps([0,1])).then(e=>new e.AppLauncherWeb)});export{_ as AppLauncher};
