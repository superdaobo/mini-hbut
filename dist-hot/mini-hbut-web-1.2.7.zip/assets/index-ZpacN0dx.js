import{invoke as n}from"./core-DhEqZVGG.js";async function p(e){await n("plugin:keep-screen-on|keep_screen_on",{enable:e})}export{p as keepScreenOn};
