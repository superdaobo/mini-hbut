const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B942CH4w.js","assets/index-DNzFMgCo.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./index-C8bepJEK.js";import{registerPlugin as o}from"./index-DNzFMgCo.js";const i=o("Preferences",{web:()=>r(()=>import("./web-B942CH4w.js"),__vite__mapDeps([0,1])).then(e=>new e.PreferencesWeb)});export{i as Preferences};
