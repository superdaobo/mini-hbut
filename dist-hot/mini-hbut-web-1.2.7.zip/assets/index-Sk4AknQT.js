const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DRnNXkco.js","assets/index-DNzFMgCo.js"])))=>i.map(i=>d[i]);
import{_ as p}from"./index-C8bepJEK.js";import{registerPlugin as r}from"./index-DNzFMgCo.js";const _=r("App",{web:()=>p(()=>import("./web-DRnNXkco.js"),__vite__mapDeps([0,1])).then(e=>new e.AppWeb)});export{_ as App};
